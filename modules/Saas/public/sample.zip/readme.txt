--- Page Builder Tags Guide ---

Available Tags:
[PAGE_BUILDER_BASE_URL] - Full URL path to your theme, suitable for referencing assets like images, JavaScript, and CSS files.

[PAGE_BUILDER_PAGE_URL] - Pretty URL to your theme, designed for use in navigation links and other URLs.

[SAAS_LOGO] - The URL for your general settings logo. This logo is dynamically fetched based on your configuration and can be used across the site.

[PACKAGES] - A list of available packages, including fields such as name, description, base_price, recurring_period, and trial_period. You can use this tag to dynamically display package details.


Important Notes:
- All content should be sourced from trusted origins, including external files.
- When using external files, ensure that the hosting domain is whitelisted in your page builder settings.

Suggestions:
- Organize your asset files in a dedicated 'assets' folder for better management.
- Follow the structure demonstrated in the sample files to ensure compatibility and smooth operation with the builder plugin.

Usage Sample:
Please refer to the Pages Upload Template Section for a sample file on how to properly use these tags in your templates.

For further assistance or inquiries, feel free to reach out to our support team.

--- End of Guide ---
